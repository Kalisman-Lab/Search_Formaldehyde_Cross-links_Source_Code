package findXL;

import java.util.LinkedList;

public class CoreSearch {

	protected MSdata msData;
	protected PeptideArray peptides;
	protected ParametersFixed parametersFixed;
	protected ParametersUserDefined parametersUserDefined;
	protected Peptide[][] pepHASH;
	protected int[] ms2_num_of_peaks_in_bin;
	protected double[][] ms2_peaks_in_bin;
	protected String out_short_Linear_Peptides = "";
	protected String out_long_Linear_Peptides = "";
	protected String out_short_XL_Peptides = "";
	protected String out_long_XL_Peptides = "";
	
	public CoreSearch(MSdata msData, PeptideArray peptides, ParametersFixed parametersFixed, ParametersUserDefined parametersUserDefined) {
		this.msData = msData;
		this.peptides = peptides;
		this.parametersFixed = parametersFixed;
		this.parametersUserDefined = parametersUserDefined;
	}

	protected void preProcessing() {
		// Calculating the peptides' fragments
		System.out.print("Log: Pre-Processing: calculation of peptide fragments ...   ");
		for (Peptide pep : peptides) {
			pep.preProcessing(parametersFixed, parametersUserDefined.hashBinSizeMS2);			
		}
		System.out.println("Done.");
		// Sorting the peptide array by mass and hashing it
		System.out.print("Log: Pre-Processing: peptide mass sorting ...   ");
		peptides.sort(new PeptideComparator());
		System.out.println("Done.");
		// Hashing...
		System.out.print("Log: Pre-Processing: HASHing MS1 ...   ");
		Object[] TMPpepHASH = new Object[(int) (parametersUserDefined.maximalPeptideMassDa / parametersUserDefined.hashBinSize) + 1000];
		for (Peptide pep : peptides) {
			double pepMass = pep.totalMass;
			if (pepMass<parametersUserDefined.maximalPeptideMassDa) {
				double pepMassMinusTol = pepMass - parametersUserDefined.maximalPeptideMassDa*parametersUserDefined.toleranceMS1;
				double pepMassPlusTol = pepMass + parametersUserDefined.maximalPeptideMassDa*parametersUserDefined.toleranceMS1;
				int lowerInd = (int) (pepMassMinusTol/parametersUserDefined.hashBinSize);
				int upperInd = (int) (pepMassPlusTol/parametersUserDefined.hashBinSize);
				for (int c=lowerInd ; c<=upperInd ; c++) {
					if (TMPpepHASH[c]==null) {
						TMPpepHASH[c] = new LinkedList<Peptide>();
					}
					((LinkedList<Peptide>) TMPpepHASH[c]).add(pep);
				}
			}
		}
		pepHASH = new Peptide[TMPpepHASH.length][];
		for (int c=0 ; c<pepHASH.length ; c++) {
			if (TMPpepHASH[c]!=null) {
				pepHASH[c] = new Peptide[((LinkedList<Peptide>) TMPpepHASH[c]).size()];
				for (int cc=0 ; cc<pepHASH[c].length ; cc++) {
					pepHASH[c][cc] = ((LinkedList<Peptide>) TMPpepHASH[c]).get(cc);				
				}
			}			
		}
		System.out.println(" Done.");
		// Preparing the arrays
		ms2_num_of_peaks_in_bin = new int[(int) (parametersUserDefined.maximalMS2range / parametersUserDefined.hashBinSizeMS2) + 1000];
		ms2_peaks_in_bin = new double[(int) (parametersUserDefined.maximalMS2range / parametersUserDefined.hashBinSizeMS2) + 1000][5];
	}

	
	protected void findCandidatesResearch() {
		int recordCounter=0;
		boolean drewLine = false;
		for (MS2Event msRecord : msData) {
			drewLine = false;
			recordCounter++;
			boolean foundLinearPeptide = false;
			if (recordCounter/1000 == recordCounter/1000.0) {
				System.out.println("Log: Doing MS data record: " + recordCounter);
			}
			if ((recordCounter>5215)&(recordCounter<5217)) {
			preprocessMSrecord(msRecord);
			// Finding linear peptide matches
			int bestPeptideScore = -1;
			int bestPeptideLength = -999;
			Peptide bestLinearPeptide = null;
			int indOfMSrecord = (int) (msRecord.monoMass/parametersUserDefined.hashBinSize);
			if (pepHASH[indOfMSrecord]!=null) {
				for (int c=0 ; c<pepHASH[indOfMSrecord].length ; c++) {
					if (Math.abs(pepHASH[indOfMSrecord][c].totalMass-msRecord.monoMass)/msRecord.monoMass < parametersUserDefined.toleranceMS1) {
						int score = scorePeptideNoDetail_by(pepHASH[indOfMSrecord][c]);
						if (score>bestPeptideScore) {
							bestPeptideScore = score;
							bestPeptideLength = pepHASH[indOfMSrecord][c].seq.length();
							bestLinearPeptide = pepHASH[indOfMSrecord][c];
						}
					}
				}
			}
			if ((bestLinearPeptide!=null) && 
				(bestPeptideScore>=parametersUserDefined.linear_peptide_Minimal_Number_by_total) &&
				(bestPeptideScore*1.0/bestPeptideLength > parametersUserDefined.linear_peptide_S2_Threshold)) {
				foundLinearPeptide = true;
//				reportLinearPeptide(bestLinearPeptide, bestPeptideScore, recordCounter, msRecord);
			}
			// Finding cross-linked peptide matches
			if (!foundLinearPeptide) {
				// Going over the lower half of the total mass
				DetailedFragmentResults scoresLightPeptide = new DetailedFragmentResults();
				DetailedFragmentResults scoresHeavyPeptide = new DetailedFragmentResults();
				int binOfMatchingPeptide;
				int bestCrossLinkScore = -1;
				Peptide bestLightPep = null;
				Peptide bestHeavyPep = null;
				for (Peptide pep : peptides) {
					if (pep.totalMass > (msRecord.monoMass+5.0)) {
						break;
					}
					// searching for matches
					// Is light peptide with a long enough streak?
					scorePeptideDetailWithStreak(pep, scoresLightPeptide);
					if ((scoresLightPeptide.scoreBYby>6) || 
							(scoresLightPeptide.scoreBYby*1.0/pep.seq.length() >= 0.5)){
						if (!drewLine) {
							drewLine = true;
							System.out.println("------------------------------------------------------------------------------------------- " + recordCounter + "\t" + msRecord.monoMass);
						}
						if (pep.protein.proteinName.equals("PP14B_HUMAN")) {
						System.out.println(pep.protein.proteinName + "\t" + 
								Math.round(100.0*(scoresLightPeptide.scoreBYby*1.0/pep.seq.length()))/100.0 + "\t" +
								scoresLightPeptide.scoreBYby + "\t" + 
								Math.round(pep.totalMass/msRecord.monoMass*100) + "\t" +
								Math.round(pep.totalMass*100)/100.0 + "\t" + 
								pep.seq);
						}
					}
				}	// Search on all light peptides
			} // Found linear peptides
		}
		} // Going over all the records
	}
	
	
	
	
	protected void findCandidates() {
		int recordCounter=0;
		boolean drewLine = false;
		for (MS2Event msRecord : msData) {
			drewLine = false;
			recordCounter++;
			boolean foundLinearPeptide = false;
			if (recordCounter/1000 == recordCounter/1000.0) {
				System.out.println("Log: Doing MS data record: " + recordCounter);
			}
			preprocessMSrecord(msRecord);
			// Finding linear peptide matches
			int bestPeptideScore = -1;
			int bestPeptideLength = -999;
			Peptide bestLinearPeptide = null;
			int bestPeptideOffset = -1;
			double massToUse = -1;
			for (int monoIsoCounter = 0; monoIsoCounter<= parametersUserDefined.maxErrorForLinearPeptides ; monoIsoCounter++) {
				massToUse = msRecord.monoMass - parametersFixed.peptideMassWithhMonoIsoError[monoIsoCounter];
				int indOfMSrecord = (int) (massToUse/parametersUserDefined.hashBinSize);
				if (pepHASH[indOfMSrecord]!=null) {
					for (int c=0 ; c<pepHASH[indOfMSrecord].length ; c++) {
						if (Math.abs(pepHASH[indOfMSrecord][c].totalMass-massToUse)/massToUse < parametersUserDefined.toleranceMS1) {
							int score = scorePeptideNoDetail_by(pepHASH[indOfMSrecord][c]);
							if (score>bestPeptideScore) {
								bestPeptideScore = score;
								bestPeptideLength = pepHASH[indOfMSrecord][c].seq.length();
								bestLinearPeptide = pepHASH[indOfMSrecord][c];
								bestPeptideOffset = monoIsoCounter;
							}
						}
					}
				}
			}
			if ((bestLinearPeptide!=null) && 
				(bestPeptideScore>=parametersUserDefined.linear_peptide_Minimal_Number_by_total) &&
				(bestPeptideScore*1.0/bestPeptideLength > parametersUserDefined.linear_peptide_S2_Threshold)) {
				foundLinearPeptide = true;
				reportLinearPeptide(bestLinearPeptide, bestPeptideScore, bestPeptideOffset, recordCounter, msRecord);
			}
			// Finding cross-linked peptide matches
			if (!foundLinearPeptide) {
				// Going over the lower half of the total mass
				DetailedFragmentResults scoresLightPeptide = new DetailedFragmentResults();
				DetailedFragmentResults scoresHeavyPeptide = new DetailedFragmentResults();
				int binOfMatchingPeptide;
				int bestCrossLinkScore = -1;
				int bestCrossLinkMonoOffset = -1;
				double bestCrossLinkMass = -999999.9;
				Peptide bestLightPep = null;
				Peptide bestHeavyPep = null;
				for (Peptide pep : peptides) {
					if (pep.totalMass > (msRecord.monoMass/2 + 2.0)) {
						break;
					}
					// searching for matches
					// Is light peptide with a long enough streak?
					scorePeptideDetailWithStreak(pep, scoresLightPeptide);
					if ((scoresLightPeptide.maxStreakAll >= parametersUserDefined.cross_links_minimial_streak_on_each_peptide) && 
							( (scoresLightPeptide.scoreBYby*1.0/pep.seq.length() >= parametersUserDefined.cross_links_minimial_S2_for_each_peptide) || 
							  (scoresLightPeptide.scoreBYby >= parametersUserDefined.cross_links_minimial_Frag_Num_for_each_peptide) )	){
						for (int monoIsoCounter = 0; monoIsoCounter<= parametersUserDefined.maxErrorForCrossLinkedPeptides ; monoIsoCounter++) {
							massToUse = msRecord.monoMass - parametersFixed.crossLinkerMassWithhMonoIsoError[monoIsoCounter];
							binOfMatchingPeptide = (int) ((massToUse-pep.totalMass)/parametersUserDefined.hashBinSize);
							if (pepHASH[binOfMatchingPeptide] != null) {
								for (int c=0 ; c<pepHASH[binOfMatchingPeptide].length ; c++) {
									// Is match with correct weight?
									if (Math.abs(massToUse-pep.totalMass-pepHASH[binOfMatchingPeptide][c].totalMass)/massToUse < parametersUserDefined.toleranceMS1) {
										// Is long peptide with a long enough streak?
										scorePeptideDetailWithStreak(pepHASH[binOfMatchingPeptide][c], scoresHeavyPeptide);
										if ((scoresHeavyPeptide.maxStreakAll >= parametersUserDefined.cross_links_minimial_streak_on_each_peptide) && 
												 (  (scoresHeavyPeptide.scoreBYby*1.0/pepHASH[binOfMatchingPeptide][c].seq.length() >= parametersUserDefined.cross_links_minimial_S2_for_each_peptide) ||
												    (scoresHeavyPeptide.scoreBYby*1.0 >= parametersUserDefined.cross_links_minimial_Frag_Num_for_each_peptide)  )	) {
											// This can be a potential cross-link. Process it further.
											//										if ((scoresLightPeptide.scoreBYby+scoresHeavyPeptide.scoreBYby)*1.0/(pep.seq.length()+pepHASH[binOfMatchingPeptide][c].seq.length()) > parametersUserDefined.cross_links_S2_Threshold) {
											//											if (!drewLine) {
											//												drewLine = true;
											//												System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------");
											//											}
											//											System.out.println(pep.protein.proteinName + "\t" + pepHASH[binOfMatchingPeptide][c].protein.proteinName + "\t" + 
											//													((scoresLightPeptide.scoreBYby+scoresHeavyPeptide.scoreBYby)*1.0/(pep.seq.length()+pepHASH[binOfMatchingPeptide][c].seq.length())) + "\t" +
											//													scoresLightPeptide.scoreBYby + "\t" + scoresHeavyPeptide.scoreBYby + "\t" +  
											//													pep.startIndexInProt + "\t" + pepHASH[binOfMatchingPeptide][c].startIndexInProt + "\t" +
											//													((msRecord.monoMass-pep.totalMass-pepHASH[binOfMatchingPeptide][c].totalMass-24.0)/msRecord.monoMass*1e6) + "\t" +
											//													pep.seq + "\t" + pepHASH[binOfMatchingPeptide][c].seq + "\t" + recordCounter + "\t" + msRecord.retentionTime);
											//											reportXL(pep, pepHASH[binOfMatchingPeptide][c], recordCounter, msRecord);
											//										}
											if ((scoresLightPeptide.scoreBYby+scoresHeavyPeptide.scoreBYby)*1.0/(pep.seq.length()+pepHASH[binOfMatchingPeptide][c].seq.length()) > parametersUserDefined.cross_links_S2_Threshold) {
//												System.out.println(pep.protein.proteinName + "\t" + pepHASH[binOfMatchingPeptide][c].protein.proteinName + "\t" + 
//														((scoresLightPeptide.scoreBYby+scoresHeavyPeptide.scoreBYby)*1.0/(pep.seq.length()+pepHASH[binOfMatchingPeptide][c].seq.length())) + "\t" +
//														scoresLightPeptide.scoreBYby + "\t" + scoresHeavyPeptide.scoreBYby + "\t" +  
//														pep.startIndexInProt + "\t" + pepHASH[binOfMatchingPeptide][c].startIndexInProt + "\t" +
//														((massToUse-pep.totalMass-pepHASH[binOfMatchingPeptide][c].totalMass)/massToUse*1e6) + "\t" +
//														pep.seq + "\t" + pepHASH[binOfMatchingPeptide][c].seq + "\t" + monoIsoCounter + "\t" +
//														msRecord.monoMass + "\t" + msRecord.mz + "\t" + msRecord.charge + "\t" + msRecord.retentionTime + "\t" + recordCounter); 

												if (bestCrossLinkScore < (scoresLightPeptide.scoreBYby+scoresHeavyPeptide.scoreBYby)) {
													bestCrossLinkScore = (scoresLightPeptide.scoreBYby+scoresHeavyPeptide.scoreBYby);
													bestLightPep = pep;
													bestHeavyPep = pepHASH[binOfMatchingPeptide][c];
													bestCrossLinkMonoOffset = monoIsoCounter;
													bestCrossLinkMass = massToUse;
												}
											}
										}									
									}
								}
							}
						} // Loop on monoisotopic mass errors.
					}
				}	// Search on all light peptides
				if ((bestLightPep!=null) && 
					(bestCrossLinkScore*1.0/(bestLightPep.seq.length()+bestHeavyPep.seq.length()) > parametersUserDefined.cross_links_S2_Threshold)) {
					scorePeptideDetailWithStreak(bestLightPep, scoresLightPeptide);
					scorePeptideDetailWithStreak(bestHeavyPep, scoresHeavyPeptide);
					System.out.println(bestLightPep.protein.proteinName + "\t" + bestHeavyPep.protein.proteinName + "\t" + 
							(bestCrossLinkScore*1.0/(bestLightPep.seq.length()+bestHeavyPep.seq.length())) + "\t" +
							scoresLightPeptide.scoreBYby + "\t" + scoresHeavyPeptide.scoreBYby + "\t" +  
							bestLightPep.startIndexInProt + "\t" + bestHeavyPep.startIndexInProt + "\t" +
							((bestCrossLinkMass-bestLightPep.totalMass-bestHeavyPep.totalMass)/bestCrossLinkMass*1e6) + "\t" +
							bestLightPep.seq + "\t" + bestHeavyPep.seq + "\t" + bestCrossLinkMonoOffset + "\t" +
							msRecord.monoMass + "\t" + msRecord.mz + "\t" + msRecord.charge + "\t" + msRecord.retentionTime + "\t" + recordCounter + "\t" +
							Math.min(scoresLightPeptide.scoreBYby, scoresHeavyPeptide.scoreBYby) + "\t" +
							// MS2 tolerances
							1e6*(scoresLightPeptide.meanOffset*bestLightPep.seq.length()+scoresHeavyPeptide.meanOffset*bestHeavyPep.seq.length())/
							(bestLightPep.seq.length()+bestHeavyPep.seq.length()) + "\t" +
							1e6*Math.sqrt(scoresHeavyPeptide.varOffset - scoresHeavyPeptide.meanOffset*scoresHeavyPeptide.meanOffset)
							); 
					reportXL(bestLightPep, bestHeavyPep, bestCrossLinkMonoOffset, recordCounter, msRecord);
				}
			} // Search for cross-links
		} // Going over all the records
	}
	

	/* Output structure of the boolean array:
	 * b12Series
	 * bSeries
	 * ySeries
	 * y12Series
	 */
	protected void scorePeptideDetailWithStreak(Peptide pep, DetailedFragmentResults results) {
		results.fragments_BbyY = new boolean[4][pep.seq.length()];
		results.maxStreak = new int[4];
		int[] tmpStreak = new int[4];
		results.scoreB = 0;
		results.scoreb = 0;
		results.scorey = 0;
		results.scoreY = 0;
		results.maxStreakAll = 0;
		results.meanOffset = 0.0;
		results.varOffset = 0.0;
		int bin,c,cc;
		double diff;
		// Doing B12,b,y,Y12 series
		for (c=0 ; c<pep.seq.length() ; c++) {
			// Doing b12 series
			results.fragments_BbyY[0][c] = false;
			bin = pep.bSeqPlus12Ind[c];
			if (ms2_num_of_peaks_in_bin[bin]>0) {
				for (cc=0 ; cc<ms2_num_of_peaks_in_bin[bin] ; cc++) {
					diff = (ms2_peaks_in_bin[bin][cc]-pep.bSeqPlus12[c])/pep.bSeqPlus12[c];
					if ((diff<parametersUserDefined.toleranceMS2) && (diff>(-parametersUserDefined.toleranceMS2))) {
						results.meanOffset += diff;
						results.varOffset += diff*diff;
						results.fragments_BbyY[0][c] = true;
						results.scoreB++;
						tmpStreak[0]++;
					}
				}
			}
			if (!results.fragments_BbyY[0][c]) { // Streak ended
				if (tmpStreak[0]>results.maxStreak[0]) {
					results.maxStreak[0] = tmpStreak[0];
				}
				tmpStreak[0] = 0;
			}
			// Doing b series
			results.fragments_BbyY[1][c] = false;
			bin = pep.bSeqInd[c];
			if (ms2_num_of_peaks_in_bin[bin]>0) {
				for (cc=0 ; cc<ms2_num_of_peaks_in_bin[bin] ; cc++) {
					diff = (ms2_peaks_in_bin[bin][cc]-pep.bSeq[c])/pep.bSeq[c];
					if ((diff<parametersUserDefined.toleranceMS2) && (diff>(-parametersUserDefined.toleranceMS2))) {
						results.meanOffset += diff;
						results.varOffset += diff*diff;
						results.fragments_BbyY[1][c] = true;
						results.scoreb++;
						tmpStreak[1]++;
					}
				}
			}			
			if (!results.fragments_BbyY[1][c]) { // Streak ended
				if (tmpStreak[1]>results.maxStreak[1]) {
					results.maxStreak[1] = tmpStreak[1];
				}
				tmpStreak[1] = 0;
			}
			// Doing y series
			results.fragments_BbyY[2][pep.seq.length()-c-1] = false;
			bin = pep.ySeqInd[c];
			if (ms2_num_of_peaks_in_bin[bin]>0) {
				for (cc=0 ; cc<ms2_num_of_peaks_in_bin[bin] ; cc++) {
					diff = (ms2_peaks_in_bin[bin][cc]-pep.ySeq[c])/pep.ySeq[c];
					if ((diff<parametersUserDefined.toleranceMS2) && (diff>(-parametersUserDefined.toleranceMS2))) {
						results.meanOffset += diff;
						results.varOffset += diff*diff;
						results.fragments_BbyY[2][pep.seq.length()-c-1] = true;
						results.scorey++;
						tmpStreak[2]++;
					}
				}
			}	
			if (!results.fragments_BbyY[2][c]) { // Streak ended
				if (tmpStreak[2]>results.maxStreak[2]) {
					results.maxStreak[2] = tmpStreak[2];
				}
				tmpStreak[2] = 0;
			}
			// Doing y12 series
			results.fragments_BbyY[3][pep.seq.length()-c-1] = false;
			bin = pep.ySeqPlus12Ind[c];
			if (ms2_num_of_peaks_in_bin[bin]>0) {
				for (cc=0 ; cc<ms2_num_of_peaks_in_bin[bin] ; cc++) {
					diff = (ms2_peaks_in_bin[bin][cc]-pep.ySeqPlus12[c])/pep.ySeqPlus12[c];
					if ((diff<parametersUserDefined.toleranceMS2) && (diff>(-parametersUserDefined.toleranceMS2))) {
						results.meanOffset += diff;
						results.varOffset += diff*diff;
						results.fragments_BbyY[3][pep.seq.length()-c-1] = true;
						results.scoreY++;
						tmpStreak[3]++;
					}
				}
			}
			if (!results.fragments_BbyY[3][c]) { // Streak ended
				if (tmpStreak[3]>results.maxStreak[3]) {
					results.maxStreak[3] = tmpStreak[3];
				}
				tmpStreak[3] = 0;
			}
		} // of the loop on all the residues
		if (results.fragments_BbyY[0][pep.seq.length()-1]) { // Streak ended at the end of peptide
			if (tmpStreak[0]>results.maxStreak[0]) {
				results.maxStreak[0] = tmpStreak[0];
			}
		}
		if (results.fragments_BbyY[1][pep.seq.length()-1]) { // Streak ended at the end of peptide
			if (tmpStreak[1]>results.maxStreak[1]) {
				results.maxStreak[1] = tmpStreak[1];
			}
		}
		if (results.fragments_BbyY[2][pep.seq.length()-1]) { // Streak ended at the end of peptide
			if (tmpStreak[2]>results.maxStreak[2]) {
				results.maxStreak[2] = tmpStreak[2];
			}
		}
		if (results.fragments_BbyY[3][pep.seq.length()-1]) { // Streak ended at the end of peptide
			if (tmpStreak[3]>results.maxStreak[3]) {
				results.maxStreak[3] = tmpStreak[3];
			}
		}
		results.scoreBYby = results.scoreB + results.scoreb + results.scorey + results.scoreY;
		results.meanOffset /= results.scoreBYby;
		results.varOffset /= results.scoreBYby;
		if ((results.maxStreak[0]>=results.maxStreak[1]) && (results.maxStreak[0]>=results.maxStreak[2]) && (results.maxStreak[0]>=results.maxStreak[3])) {
			results.maxStreakAll = results.maxStreak[0];
		}
		else if ((results.maxStreak[1]>=results.maxStreak[2]) && (results.maxStreak[1]>=results.maxStreak[3])) {
			results.maxStreakAll = results.maxStreak[1];
		}
		else if ((results.maxStreak[2]>=results.maxStreak[3])) {
			results.maxStreakAll = results.maxStreak[2];
		}
		else {
			results.maxStreakAll = results.maxStreak[3];
		}
	}
	

	protected int[] scorePeptideNoDetail_byBY(Peptide pep) {
		int[] totalScore = {0,0};
		totalScore[0] += compareFragsNoDetail(pep.bSeq, pep.bSeqInd);
		totalScore[0] += compareFragsNoDetail(pep.ySeq, pep.ySeqInd);
		totalScore[1] += compareFragsNoDetail(pep.bSeqPlus12, pep.bSeqPlus12Ind);
		totalScore[1] += compareFragsNoDetail(pep.ySeqPlus12, pep.ySeqPlus12Ind);
		return totalScore;
	}

	
	protected int scorePeptideNoDetail_by(Peptide pep) {
		int totalScore = 0;
		totalScore += compareFragsNoDetail(pep.bSeq, pep.bSeqInd);
		totalScore += compareFragsNoDetail(pep.ySeq, pep.ySeqInd);
		return totalScore;
	}
	
	
	protected int compareFragsNoDetail(double[] frags, int[] fragsInds) {
		int hits = 0;
		int c,cc;
		double diff;
		for (c=0 ; c<frags.length ; c++) {
			int bin = fragsInds[c];
			if (ms2_num_of_peaks_in_bin[bin]>0) {
				for (cc=0 ; cc<ms2_num_of_peaks_in_bin[bin] ; cc++) {
					diff = (ms2_peaks_in_bin[bin][cc]-frags[c])/frags[c];
					if ((diff<parametersUserDefined.toleranceMS2) && (diff>(-parametersUserDefined.toleranceMS2))) {
						hits++;
					}
				}
			}			
		}
		return hits;
	}
	
	protected void preprocessMSrecord(MS2Event msRecord) {
		for (int c=0 ; c<ms2_num_of_peaks_in_bin.length ; c++) {
			ms2_num_of_peaks_in_bin[c] = 0;
		}
		for (int c=0 ; c<msRecord.fragments.length ; c++) {
			double fragMass = msRecord.fragments[c][0];
			if (fragMass<parametersUserDefined.maximalMS2range) {
				double fragMassMinusTol = fragMass - fragMass*parametersUserDefined.toleranceMS2;
				double fragMassPlusTol = fragMass + fragMass*parametersUserDefined.toleranceMS2;
				int lowerInd = (int) (fragMassMinusTol/parametersUserDefined.hashBinSizeMS2);
				int upperInd = (int) (fragMassPlusTol/parametersUserDefined.hashBinSizeMS2);
				for (int cc=lowerInd ; cc<=upperInd ; cc++) {
					ms2_num_of_peaks_in_bin[cc]++;
					ms2_peaks_in_bin[cc][ms2_num_of_peaks_in_bin[cc]-1] = fragMass;
				}
			}
		}		
	}
	
	protected void 	reportLinearPeptide(Peptide bestLinearPeptide, int bestPeptideScore, int bestPeptideOffset, int recordCounter, MS2Event record) {
		DetailedFragmentResults scoresLinearPeptide = new DetailedFragmentResults();
		scorePeptideDetailWithStreak(bestLinearPeptide, scoresLinearPeptide);
		out_short_Linear_Peptides += (bestLinearPeptide.protein.proteinName + "\t" + bestPeptideScore + "\t" + 
				recordCounter + "\t" + record.charge + "\t" + record.mz + "\t" + bestPeptideOffset + "\t" +
				bestLinearPeptide.startIndexInProt + "\t" + bestLinearPeptide.endIndexInProt + "\t" + bestLinearPeptide.seq + "\n");

		String tmpOut = "";
		tmpOut += ("----------------------------------------------------------------\n" + bestLinearPeptide.protein.proteinName + "\n");
		boolean[][] by = scoresLinearPeptide.fragments_BbyY;
		for (int c=0 ; c<bestLinearPeptide.seq.length() ; c++) {
			if (by[0][c]) {
				tmpOut += "B";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += "\n";
		for (int c=0 ; c<bestLinearPeptide.seq.length() ; c++) {
			if (by[1][c]) {
				tmpOut += "b";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += ("\n" + bestLinearPeptide.seq + "\n");
		for (int c=0 ; c<bestLinearPeptide.seq.length() ; c++) {
			if (by[2][c]) {
				tmpOut += "y";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += "\n";
		for (int c=0 ; c<bestLinearPeptide.seq.length() ; c++) {
			if (by[3][c]) {
				tmpOut += "Y";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += "\n";
		out_long_Linear_Peptides += tmpOut;
	}

	protected void 	reportXL(Peptide bestLightPeptide, Peptide bestHeavyPeptide, int bestCrossLinkMonoOffset, int recordCounter, MS2Event record) {
		DetailedFragmentResults scoresLightPeptide = new DetailedFragmentResults();
		DetailedFragmentResults scoresHeavyPeptide = new DetailedFragmentResults();
		scorePeptideDetailWithStreak(bestLightPeptide, scoresLightPeptide);
		scorePeptideDetailWithStreak(bestHeavyPeptide, scoresHeavyPeptide);
		out_short_XL_Peptides += (bestLightPeptide.protein.proteinName + "\t" + bestHeavyPeptide.protein.proteinName + "\t" +
				((scoresLightPeptide.scoreBYby+scoresHeavyPeptide.scoreBYby)*1.0/(bestLightPeptide.seq.length()+bestHeavyPeptide.seq.length())) + "\t" + 
				recordCounter + "\t" + record.charge + "\t" + record.mz + "\t" + bestCrossLinkMonoOffset + "\t" +  
				bestLightPeptide.startIndexInProt + "\t" + bestHeavyPeptide.startIndexInProt + "\t" + bestLightPeptide.seq + "\t" + bestHeavyPeptide.seq + "\n");

		String tmpOut = "";
		tmpOut += ("----------------------------------------------------------------\n" + bestLightPeptide.protein.proteinName + "  " + 
		bestHeavyPeptide.protein.proteinName + "\n");
		boolean[][] by = scoresLightPeptide.fragments_BbyY;
		for (int c=0 ; c<bestLightPeptide.seq.length() ; c++) {
			if (by[0][c]) {
				tmpOut += "B";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += "\n";
		for (int c=0 ; c<bestLightPeptide.seq.length() ; c++) {
			if (by[1][c]) {
				tmpOut += "b";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += ("\n" + bestLightPeptide.seq + "\n");
		for (int c=0 ; c<bestLightPeptide.seq.length() ; c++) {
			if (by[2][c]) {
				tmpOut += "y";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += "\n";
		for (int c=0 ; c<bestLightPeptide.seq.length() ; c++) {
			if (by[3][c]) {
				tmpOut += "Y";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += "\n\n";

		by = scoresHeavyPeptide.fragments_BbyY;
		for (int c=0 ; c<bestHeavyPeptide.seq.length() ; c++) {
			if (by[0][c]) {
				tmpOut += "B";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += "\n";
		for (int c=0 ; c<bestHeavyPeptide.seq.length() ; c++) {
			if (by[1][c]) {
				tmpOut += "b";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += ("\n" + bestHeavyPeptide.seq + "\n");
		for (int c=0 ; c<bestHeavyPeptide.seq.length() ; c++) {
			if (by[2][c]) {
				tmpOut += "y";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += "\n";
		for (int c=0 ; c<bestHeavyPeptide.seq.length() ; c++) {
			if (by[3][c]) {
				tmpOut += "Y";
			}
			else {
				tmpOut += " ";
			}					
		}
		tmpOut += "\n";		
		
		out_long_XL_Peptides += tmpOut;
	}

	
}

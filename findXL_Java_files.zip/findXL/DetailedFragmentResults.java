package findXL;

public class DetailedFragmentResults {

	boolean[][] fragments_BbyY;
	int[] maxStreak;
	int maxStreakAll;
	int scoreB;
	int scoreb;
	int scorey;
	int scoreY;
	int scoreBYby;
	double meanOffset;
	double varOffset;
	
}

package findXL;
import java.util.StringTokenizer;
import java.util.Vector;

public class FastaProteinDatabase extends Vector<Protein>  {

	private static final long serialVersionUID = -2976807366576677359L;

	protected final int numberOfDecoySequences;
	protected final int numberOfOriginalSequences;
	
	public FastaProteinDatabase(String fastaFileName, ParametersUserDefined params) {
		System.out.println("Log: Loading FASTA file: " + fastaFileName + "  ...  ");
		String[] text = File2StringArray.f2a(fastaFileName);
		String proteinName="";
		String proteinAccession="";
		String proteinDescription="";
		String seq="[";
		boolean inSeq = false;
		int seqCounter=1;
		for (int c=0 ; c<text.length ; c++) {
			if (text[c].startsWith(">")) {
				if (inSeq) {
					seq += "]";
					add(new Protein(seq, proteinName, proteinAccession, proteinDescription, seqCounter, false));
				}
				seq = "[";
				proteinName = parseProteinName(text[c]);
				proteinAccession = parseProteinAccession(text[c]);
				proteinDescription = parseProteinDescription(text[c]);
				inSeq = true;
				seqCounter++;
			}
			else {
				seq += (text[c]).replace('B', 'D');
			}
		}
		if (inSeq) {
			seq += "]";
			add(new Protein(seq, proteinName, proteinAccession, proteinDescription, seqCounter, false));
		}
		numberOfOriginalSequences = size();
		System.out.println("Log: Loaded " + this.size() + " sequences.");
		// Adding the decoy sequences
		if (params.useDecoySeq){
			if (size() < params.minNumOfSequencesForFraction) {
				for (int c=0; c<numberOfOriginalSequences ; c++) {
					seqCounter++;
					String origSeq = elementAt(c).seq;
					String origSeqNoTermini = origSeq.substring(1, origSeq.length()-1);
					seq = "[";
					for (int c1=origSeqNoTermini.length()-1; c1>=0; c1-- ) {
						seq += origSeqNoTermini.charAt(c1);
					}
					seq += "]";
					add(new Protein(seq, "decoy_"+c, "D00"+c, "Decoy number "+c, seqCounter, true));
				}
				System.out.println("Log: Added " + numberOfOriginalSequences + " decoy sequences.   Done.");
				numberOfDecoySequences = numberOfOriginalSequences;
			}
			else {
				int jumpSize = (int) (1/params.fractionOfSeqNumberForDecoys);
				int decoyCounter = 0;
				for (int c=0; c<numberOfOriginalSequences ; c+=jumpSize) {
					seqCounter++;
					decoyCounter++;
					String origSeq = elementAt(c).seq;
					String origSeqNoTermini = origSeq.substring(1, origSeq.length()-1);
					seq = "[";
					for (int c1=origSeqNoTermini.length()-1; c1>=0; c1-- ) {
						seq += origSeqNoTermini.charAt(c1);
					}
					seq += "]";
					add(new Protein(seq, "decoy_"+decoyCounter, "D00"+decoyCounter, "Decoy number "+decoyCounter, seqCounter, true));
				}
				System.out.println("Log: Added " + decoyCounter + " decoy sequences.   Done.");
				numberOfDecoySequences = decoyCounter;
			}			
		}
		else {
			System.out.println("Log: No decoy sequences.   Done.");
			numberOfDecoySequences = 0;
		}
		
	}

	// out of a SwissProt header line
	private String parseProteinDescription(String str) {
		StringTokenizer tok1 = new StringTokenizer(str, "|");
		tok1.nextToken();
		if (tok1.hasMoreTokens()) {
			tok1.nextToken(); // skipping the accession code
			if (tok1.hasMoreTokens()) {
				tok1.nextToken(" ");
				return tok1.nextToken("\n");
			}
			else {
				return null;				
			}
		}
		else {
			return null;
		}
	}
	
	// out of a SwissProt header line
	private String parseProteinName(String str) {
		StringTokenizer tok1 = new StringTokenizer(str, "|");
		tok1.nextToken();
		if (tok1.hasMoreTokens()) {
			tok1.nextToken(); // skipping the accession code
			if (tok1.hasMoreTokens()) {
				return tok1.nextToken(" ").substring(1);
			}
			else {
				return null;				
			}
		}
		else {
			return null;
		}
	}

	// out of a SwissProt header line
	private String parseProteinAccession(String str) {
		StringTokenizer tok1 = new StringTokenizer(str, "|");
		tok1.nextToken();
		if (tok1.hasMoreTokens()) {
			return tok1.nextToken();
		}
		else {
			return null;
		}
	}	

	
	public void print() {
		for (Protein seq : this) {
			System.out.println(seq);
		}
	}

	
	public String toString() {
		String out = "";
		for (Protein seq : this) {
			out += seq.toString();
		}
		return out;
	}

	
}

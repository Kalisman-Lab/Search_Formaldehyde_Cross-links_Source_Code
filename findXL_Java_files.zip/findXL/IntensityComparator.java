package findXL;

import java.util.Comparator;

public class IntensityComparator implements Comparator<double[]> {
	
	public int compare(double[] arg0, double[] arg1) {
		if (arg0[1]<arg1[1]) 
			return -1;
		else if (arg0[1]>arg1[1]) 
			return 1;
		else
			return 0;
	}
}

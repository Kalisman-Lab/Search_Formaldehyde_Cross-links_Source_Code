package findXL;

public class MS2Event {

	protected int dataRecordNum;
	protected double monoMass; 
	protected double mz; 
	protected int charge; 
	protected double retentionTime; 
	protected int scanNumber; 
	protected double intensity; 
	protected double[][] fragments;
	protected String MGFfileName;
	
	public MS2Event(int dataRecordNum, double monoMass, double mz, int charge, double retentionTime, int scanNumber, double intensity, double[][] fragments, String MGFfileName) {
		this.dataRecordNum = dataRecordNum;
		this.monoMass = monoMass;
		this.mz = mz;
		this.charge = charge;
		this.retentionTime = retentionTime;
		this.scanNumber = scanNumber;
		this.intensity = intensity;
		this.fragments = fragments;
		this.MGFfileName = MGFfileName;
	}

}

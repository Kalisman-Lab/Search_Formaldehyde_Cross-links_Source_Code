package findXL;

import java.util.StringTokenizer;
import java.util.Vector;

public class MSdata extends Vector<MS2Event> {

	private static final long serialVersionUID = -656982822528528226L;
	private double takePeaksTill = 0.99;
	private double fragmantationMassTol;
	private final double ProtonMass = 1.0072764;
	private final double daPerRes = 112.47;
	private final double cPerRes = 4.94;
	private final int maxC13Isotope = 3;
	private final int maxChargeState = 4;
	private final double c13P = 0.0111;
	private final double c13Delta = 1.003354838;
	

	public MSdata(String MGFfileName, double ms1Offset, double ms2Offset, double ms2Tolerance) {
		super(1000,1000);
		fragmantationMassTol = ms2Tolerance*1.5*1e6;
		readMGFfile(MGFfileName, ms1Offset,  ms2Offset);
	}	
	
	private void readMGFfile(String MGFfileName, double ms1Offset, double ms2Offset) {
		System.out.println("Log: Loading MGF file: " + MGFfileName + "  ...  ");
		String[] text = File2StringArray.f2a(MGFfileName);
		
		int ms2Counter = 0;
		double mz=0.0;
		int charge=-999;
		double retentionTime=0.0;
		int scanNumber=0;
		double Iprecurssor=0.0;
		double monoMass;
		Vector<double[]> spectrum = new Vector<double[]>(100,100);
		boolean readingIonList = false;

		for (int linC = 0; linC<text.length ; linC++) {
			String lin = text[linC];
			if (lin.startsWith("END IONS")) {
				monoMass =  (mz*charge - 1.0072764*charge)*(1-ms1Offset*1e-6);
				add(new MS2Event(ms2Counter, monoMass, mz, charge, retentionTime, scanNumber, Iprecurssor, getTrueMasses(spectrum,ms2Offset), MGFfileName));
				ms2Counter = ms2Counter + 1;
				if ((ms2Counter%5000) == 0) {
					System.out.println("Log: So far read " + ms2Counter + " of MS/MS events");
				}
				readingIonList = false;
				spectrum = new Vector<double[]>(100,100);
			}
			else if	(lin.startsWith("PEPMASS=")) {
				StringTokenizer st = new StringTokenizer(lin.substring(8));
				mz = Double.parseDouble(st.nextToken());
				Iprecurssor = Double.parseDouble(st.nextToken());
			}
			else if (lin.startsWith("CHARGE=")) {
				charge = Integer.parseInt(lin.substring(7,8));
			}
			else if (lin.startsWith("RTINSECONDS=")) {
				retentionTime = Double.parseDouble(lin.substring(12));
			}
			else if (lin.startsWith("SCANS=")) {
				scanNumber = Integer.parseInt(lin.substring(6));
			}
			else if (lin.startsWith("TITLE=")) {
				// Currently do nothing with the TITLE
			}
			else if (lin.startsWith("BEGIN IONS")) {
				readingIonList = true;
			}
			else if (readingIonList) {
				StringTokenizer st = new StringTokenizer(lin);
				double ms2MZ = Double.parseDouble(st.nextToken());
				double ms2I = Double.parseDouble(st.nextToken());
				double[] peak = {ms2MZ, ms2I, spectrum.size()};
				spectrum.add(peak);
			}
		}
		System.out.println("Log: Read a total of " + ms2Counter + " MS2 events.");
	}	
	
	
	private double[][] getTrueMasses(Vector<double[]> spectrum, double ms2Offset) {
		
		// Initializing
		boolean[] assigned = new boolean[spectrum.size()];
		for (int ccc=0; ccc<spectrum.size() ; ccc++) {
			assigned[ccc] = false;
		}
		Vector<double[]> trueMassList = new Vector<double[]>(20,20);
		
		// Sorting intensities:
		Vector<double[]> copySpectrum = new Vector<double[]>(spectrum.size(),1);
		for (int ccc=0; ccc<spectrum.size() ; ccc++) {
			copySpectrum.add(spectrum.elementAt(ccc));
		}
		copySpectrum.sort(new IntensityComparator());
		int[] IPeakInd = new int[copySpectrum.size()];
		for (int ccc=0; ccc<spectrum.size() ; ccc++) {
			IPeakInd[ccc] = (int) copySpectrum.elementAt(copySpectrum.size()-ccc-1)[2];
		}
		
		// Analysing the peaks in decreasing order
		for (int c=0 ; c<Math.ceil(takePeaksTill*IPeakInd.length) ; c++) {
		    int workInd = IPeakInd[c];
		    double workMZ = spectrum.elementAt(workInd)[0];
		    if (!assigned[workInd]) {
		        double bestScore = Double.NEGATIVE_INFINITY;
		        int bestCharge = -999;
		        int bestPos = -999;
		        double trueMass = -9999;
		        double estCarbonN = -9999;
		        double[] carbonDist = null;
		        // Preprocessing - start
		        Vector<Integer> possibleIndsForCorrSearch = new Vector<Integer>(10,10);
		        for (int ccc=0; ccc<spectrum.size() ; ccc++) {
		        	if ((Math.abs(spectrum.elementAt(ccc)[0]-workMZ)<4.0) & (!assigned[ccc])) {
		        		possibleIndsForCorrSearch.add(new Integer(ccc));
		        	}
		        }
		        // Preprocessing - end
		        for (int chargeState=1 ; chargeState<=maxChargeState ; chargeState++) {
		        	trueMass = spectrum.elementAt(workInd)[0]*chargeState-ProtonMass*chargeState;
		        	estCarbonN = trueMass/daPerRes*cPerRes;
		        	carbonDist = new double[maxC13Isotope+1];
		        	for (int ccc=0; ccc<=maxC13Isotope ; ccc++) {
		        		carbonDist[ccc] = Math.pow(estCarbonN*c13P,ccc) / factorial(ccc) * Math.exp(-estCarbonN*c13P);
		        	}
		        	int maxCarbonProbInd = -1;
		        	double maxCarbonProb = -999.0;
		        	for (int ccc=0; ccc<carbonDist.length ; ccc++) {
		        		if (carbonDist[ccc] > maxCarbonProb) {
		        			maxCarbonProb = carbonDist[ccc];
		        			maxCarbonProbInd = ccc;
		        		}
		        	}
		        	int carbonOffsetVecBegin;
		        	int carbonOffsetVecEnd;
		        	if (trueMass<1500.0) {
		        		carbonOffsetVecBegin = 0;
		        		carbonOffsetVecEnd = 0;
		        	}
		        	else if (trueMass<2500) {
		        		carbonOffsetVecBegin = 0;
		        		carbonOffsetVecEnd = 1;
		        	}
		        	else {
		        		carbonOffsetVecBegin = maxCarbonProbInd-1;
		        		carbonOffsetVecEnd = maxCarbonProbInd+1;
		        	}
		            for (int offsetInd=carbonOffsetVecBegin ; offsetInd<=carbonOffsetVecEnd ; offsetInd++) {
		            	double corrScore = 0.0;
		            	for (int carbonC=0 ; carbonC<=maxC13Isotope ; carbonC++) {
		            		double searchAround = workMZ + c13Delta*(carbonC-offsetInd)/chargeState;
		                    double minVal = Double.POSITIVE_INFINITY;
		                    int minInd = -1;
		                    for (int ccc=0 ; ccc<possibleIndsForCorrSearch.size() ; ccc++) {
		                    	double tmp = Math.abs(spectrum.elementAt(possibleIndsForCorrSearch.elementAt(ccc).intValue())[0]-searchAround);
		                    	if (tmp<minVal) {
		                    		minVal = tmp;
		                    		minInd = ccc;
		                    	}
		                    }
		                    if ((minVal/searchAround*1e6) < fragmantationMassTol) {
		                    	corrScore = corrScore + spectrum.elementAt(possibleIndsForCorrSearch.elementAt(minInd).intValue())[1];
		                    }
		                    else {
		                    	break;
		                    }
		            	}
		            	if (corrScore>bestScore) {
		            		bestScore = corrScore;
		            		bestCharge = chargeState;
		            		bestPos = offsetInd;
		            	}
		            }
		        } // of chargeState loop
		        
		        trueMass = spectrum.elementAt(workInd)[0]*bestCharge-ProtonMass*bestCharge;
		        estCarbonN = trueMass/daPerRes*cPerRes;
	        	for (int ccc=0; ccc<=maxC13Isotope ; ccc++) {
	        		carbonDist[ccc] = Math.pow(estCarbonN*c13P,ccc) / factorial(ccc) * Math.exp(-estCarbonN*c13P);
	        	}
	            double weightedOffset = 0.0;
	            for (int carbonC=0 ; carbonC<=maxC13Isotope ; carbonC++) {
	            	double searchAround = workMZ + c13Delta*(carbonC-bestPos)/bestCharge;
                    double minVal = Double.POSITIVE_INFINITY;
                    int minInd = -1;
                    for (int ccc=0 ; ccc<possibleIndsForCorrSearch.size() ; ccc++) {
                    	double tmp = Math.abs(spectrum.elementAt(possibleIndsForCorrSearch.elementAt(ccc).intValue())[0]-searchAround);
                    	if (tmp<minVal) {
                    		minVal = tmp;
                    		minInd = ccc;
                    	}
                    }
                    if ((minVal/searchAround*1e6) < fragmantationMassTol) {
	                    weightedOffset = weightedOffset + carbonDist[carbonC]*(spectrum.elementAt(possibleIndsForCorrSearch.elementAt(minInd).intValue())[0]-searchAround);
	                    assigned[possibleIndsForCorrSearch.elementAt(minInd).intValue()] = true;
                    }
	            }   
	            double[] toAdd = {(workMZ - bestPos*c13Delta/bestCharge + weightedOffset)*bestCharge-bestCharge*ProtonMass,
	            		bestCharge,
	            		// in the MATLAB version this was also recorded: spectrum.elementAt(workInd)[1],
	            		bestScore};
	            trueMassList.add(toAdd);		        
		    }
		}
		
		// Removing the MS2 offset
		for (int c=0; c<trueMassList.size() ; c++) {
			trueMassList.elementAt(c)[0] = trueMassList.elementAt(c)[0] * (1-ms2Offset*1e-6);
		}
		
		trueMassList.sort(new TrueMassComparator());
		
		double[][] returnArr = new double[trueMassList.size()][3];
		for (int c=0; c<trueMassList.size() ; c++) {
			for (int cc=0; cc<3 ; cc++) {
				returnArr[c][cc] = trueMassList.elementAt(c)[cc];
			}
		}
				
		return returnArr;        		
	} // End of method
	
	
	private double factorial(int n) {
		if (n==0) {
			return 1.0;
		}
		else {
			double fact = 1.0;
			for (int c=1 ; c<=n ; c++) {
				fact = fact * c;
			}
			return fact;
		}
	}
	
	
}

package findXL;

public interface Modification {
	public int[] residuesToBeModified(char[] charArr);
	public char oneLetterCodeOfModification();
	public String shortDescriptionOfModification();
}

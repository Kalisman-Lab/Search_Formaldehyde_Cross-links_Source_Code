package findXL;

import java.util.Vector;

public class ModificationCysteineWithIodoacetamide implements Modification {

	public int[] residuesToBeModified(char[] charArr) {
		Vector<Integer> out = new Vector<Integer>();
		for (int c=0; c<charArr.length ; c++) {
			if (charArr[c] == 'C') {
				out.add(new Integer(c));
			}
		}
		int[] outArr = new int[out.size()];
		for (int c=0; c<out.size() ; c++) {
			outArr[c] = out.elementAt(c).intValue();
		}
		return outArr;
	}

	public char oneLetterCodeOfModification() {
		return 'c';
	}

	public String shortDescriptionOfModification() {
		return "Carbamide";
	}

}

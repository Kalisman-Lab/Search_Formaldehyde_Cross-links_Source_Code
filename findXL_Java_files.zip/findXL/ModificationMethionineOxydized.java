package findXL;

import java.util.Vector;

public class ModificationMethionineOxydized implements Modification {

	public int[] residuesToBeModified(char[] charArr) {
		Vector<Integer> out = new Vector<Integer>();
		for (int c=0; c<charArr.length ; c++) {
			if (charArr[c] == 'M') {
				out.add(new Integer(c));
			}
		}
		int[] outArr = new int[out.size()];
		for (int c=0; c<out.size() ; c++) {
			outArr[c] = out.elementAt(c).intValue();
		}
		return outArr;
	}

	public char oneLetterCodeOfModification() {
		return 'm';
	}

	public String shortDescriptionOfModification() {
		return "Met-Oxy";
	}

}

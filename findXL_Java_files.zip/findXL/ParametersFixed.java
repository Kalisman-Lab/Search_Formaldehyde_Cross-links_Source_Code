/**
 * 
 */
package findXL;

/**
 * This class holds all the numbers that are not run dependent - masses of amino acids, atoms, etc.
 */
public class ParametersFixed {
	
	public final String aminoAcidTypes = "ACDEFGHIKLMNPQRSTVWYcm[{]XZU"; 
	
	public final double[] aminoAcidMasses = {
			71.037114 , // A
			103.00919 , // C
			115.02694 , // D
			129.04259 , // E 
			147.06841 , // F
			57.021464 , // G
			137.05891 , // H
			113.08406 , // I
			128.09496 , // K
			113.08406 , // L
			131.04048 , // M
			114.04293 , // N
			97.052764 , // P
			128.05858 , // Q
			156.10111 , // R
			87.032028 , // S
			101.04768 , // T
			99.068414 , // V
			186.07931 , // W
			163.06333 , // Y
			160.03065 , // Cystein - treated with Iodoacetamide (c)
			147.03540 , // Methionine - Oxidized (m)
			0         , // N-terminal of protein ([)
			42.010565 , // N-terminal of protein acetylated ({)
			0,           // C-terminal of protein (])
			999.5,		// X
			999.5,		// Z
			999.5		// U
	};
	
	public final double waterMass = 18.010565;
	
//	public final double[] crossLinkerMassWithhMonoIsoError = {24.000, 24.00 + 1.003355, 24.00 + 2*1.003355, 24.00 + 3*1.003355, 24.00 + 4*1.003355};
	public final double[] crossLinkerMassWithhMonoIsoError = {24.000, 24.00 + 1.003355, 24.00 + 2*1.003355, 12.000, 12.00 + 1.003355, 12.00 + 2*1.003355 , 2.003, 36.0,  36.00 + 1.003355, 36.00 + 2*1.003355/*12.00 + 2*1.003355*/};

	public final double[] peptideMassWithhMonoIsoError = {0, 0 + 1.003355, 0 + 2*1.003355,};


	/**
	 * Constructor does nothing.
	 */
	public ParametersFixed() {}
}



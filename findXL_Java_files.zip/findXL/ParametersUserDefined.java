package findXL;

public class ParametersUserDefined
{

	public double offsetMS1 = 0.5; // This value is in parts per million (ppm)
	public double offsetMS2 = 0.3; // This value is in parts per million (ppm)
	
	public double toleranceMS1 = 4.5 * 1e-6;
	public double toleranceMS2 = 6.5 * 1e-6;
	
	public double linear_peptide_S2_Threshold = 0.5;
	public int linear_peptide_Minimal_Number_by_total = 9;
	public double cross_links_minimial_Frag_Num_for_each_peptide = 11;
	public double cross_links_minimial_S2_for_each_peptide = 0.3;
	public int cross_links_minimial_streak_on_each_peptide = 3;
	public double cross_links_S2_Threshold = 0.3;
	
	public int minimalPeptideLength = 4;
	public int maximalPeptideLength = 100;
	
	public int numberMiscleavages = 2;
	
	public int maxVariableModificationsPerPeptide = 0;
	
	public boolean useDecoySeq = false;
	public double fractionOfSeqNumberForDecoys = 1.0/15;
	public int minNumOfSequencesForFraction = 100;  // If the number of sequences is lower than this constant than the number of decoys will be equal to the number of sequences. If it is higher, then the number of decoys is frac*NumOfSeq
	
	public String fastaSequenceDatabaseFileName;
				
	public String MSdataFileName; // File that was created by fastload to TXT converter

		
	// Parameters the users should not play with so much	
	public final double maximalPeptideMassDa = 8000.0;
	public final double hashBinSize = 8000.0/1000000;
	public final double maximalMS2range = 8000.0;
	public final double hashBinSizeMS2 = 8000.0/500000;

	// How to correct for the error in identifying the mono-isotopic mass
	public final int maxErrorForLinearPeptides = 2;
	public final int maxErrorForCrossLinkedPeptides = 5;
	
	/**
	 * Currently constructor does nothing
	 */
	public ParametersUserDefined()
	{
	
	}
}

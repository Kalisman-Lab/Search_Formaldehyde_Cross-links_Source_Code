package findXL;

/**
 * Represents a short linear sequence of amino acids. 
 */
public class Peptide {

	// Constants
	protected Protein protein;
	protected int startIndexInProt; 
	protected int endIndexInProt;
	protected String seq;
	protected double totalMass;
	protected double[] bSeq;
	protected double[] ySeq;
	protected double[] bSeqPlus12;
	protected double[] ySeqPlus12;
	protected int[] bSeqInd;
	protected int[] ySeqInd;
	protected int[] bSeqPlus12Ind;
	protected int[] ySeqPlus12Ind;
	// Variables
	protected boolean otherPeptideConsidered; 
	
	/**
	 * The constructor needs the fixed parameter class to calculate the masses.
	 */
	public Peptide(String seq , Protein protein, int startIndexInProt, int endIndexInProt) {
		this.seq = seq;
		this.protein = protein;
		this.startIndexInProt = startIndexInProt;
		this.endIndexInProt = endIndexInProt;
	}
	
	protected void preProcessing(ParametersFixed parameters, double MS2binSize) {
		// Calculating bSeq and bSeq+12Da
		bSeq = new double[seq.length()];
		bSeqPlus12 = new double[seq.length()];
		bSeqInd = new int[seq.length()];
		bSeqPlus12Ind = new int[seq.length()];
		bSeq[0] = parameters.aminoAcidMasses[ parameters.aminoAcidTypes.indexOf(seq.charAt(0)) ];
		bSeqPlus12[0] = parameters.aminoAcidMasses[ parameters.aminoAcidTypes.indexOf(seq.charAt(0)) ] + 12.00000;
		bSeqInd[0] = (int) (bSeq[0] / MS2binSize);
		bSeqPlus12Ind[0] = (int) (bSeqPlus12[0] / MS2binSize);
		for (int c=1 ; c<seq.length() ; c++) {
			bSeq[c] = bSeq[c-1] + parameters.aminoAcidMasses[ parameters.aminoAcidTypes.indexOf(seq.charAt(c)) ]; 
			bSeqPlus12[c] = bSeqPlus12[c-1] + parameters.aminoAcidMasses[ parameters.aminoAcidTypes.indexOf(seq.charAt(c)) ]; 
			bSeqInd[c] = (int) (bSeq[c] / MS2binSize);
			bSeqPlus12Ind[c] = (int) (bSeqPlus12[c] / MS2binSize);		
		}
		// Calculating ySeq and ySeq+12Da
		ySeq = new double[seq.length()];
		ySeqPlus12 = new double[seq.length()];
		ySeqInd = new int[seq.length()];
		ySeqPlus12Ind = new int[seq.length()];		
		ySeq[0] = parameters.aminoAcidMasses[ parameters.aminoAcidTypes.indexOf(seq.charAt(seq.length()-1)) ] + parameters.waterMass;
		ySeqPlus12[0] = parameters.aminoAcidMasses[ parameters.aminoAcidTypes.indexOf(seq.charAt(seq.length()-1)) ] + parameters.waterMass + 12.00000;
		ySeqInd[0] = (int) (ySeq[0] / MS2binSize);
		ySeqPlus12Ind[0] = (int) (ySeqPlus12[0] / MS2binSize);
		for (int c=1 ; c<seq.length() ; c++) {
			ySeq[c] = ySeq[c-1] + parameters.aminoAcidMasses[ parameters.aminoAcidTypes.indexOf(seq.charAt(seq.length()-1-c)) ]; 
			ySeqPlus12[c] = ySeqPlus12[c-1] + parameters.aminoAcidMasses[ parameters.aminoAcidTypes.indexOf(seq.charAt(seq.length()-1-c)) ];
			ySeqInd[c] = (int) (ySeq[c] / MS2binSize);
			ySeqPlus12Ind[c] = (int) (ySeqPlus12[c] / MS2binSize);			
		}
		// Total mass
		totalMass = ySeq[ySeq.length-1];
		otherPeptideConsidered = false;
	}
	
	
	public void print() {
		System.out.println(seq + "  from: " + protein.proteinName + "  " + startIndexInProt + " - " + endIndexInProt);
	}
	

}

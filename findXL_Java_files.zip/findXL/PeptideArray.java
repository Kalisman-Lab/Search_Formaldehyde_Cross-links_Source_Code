package findXL;

import java.util.Vector;

public class PeptideArray extends Vector<Peptide> {
	
	private static final long serialVersionUID = -5816247182351776343L;

	FastaProteinDatabase seqDB;
	Protease protease;
	Modification[] fixedModifications;
	Modification[] variableModifications;
	ParametersFixed parametersFixed;
	ParametersUserDefined parametersUserDefined;
	
	public PeptideArray(FastaProteinDatabase seqDB, Protease protease, Modification[] fixedModifications, Modification[] variableModifications,
			ParametersFixed parametersFixed, ParametersUserDefined parametersUserDefined)  {
		super(10000,10000);
		this.seqDB = seqDB;
		this.protease = protease;
		this.fixedModifications = fixedModifications;
		this.variableModifications = variableModifications;
		this.parametersFixed = parametersFixed;
		this.parametersUserDefined = parametersUserDefined;
		
		createInitialPeptideList();
		createModifiedPeptideList();
	}

	private void createModifiedPeptideList() {
		int initialLength = size();
		for (int c=0 ; c<initialLength ; c++) {
			Peptide pep = elementAt(c);
			char[] pepSeq = elementAt(c).seq.toCharArray();
			recursiveModificationAdder(pep, pepSeq, size() , 0);
		}
		System.out.println("Log: " + this.size() + " peptides in total with modifications.");
	}
	
	private void recursiveModificationAdder(Peptide pep, char[] pepSeqOrig, int toCheckRedundancyFrom, int numberOfModifications) {
		// Stopping condition
		if (numberOfModifications == parametersUserDefined.maxVariableModificationsPerPeptide) {
			return;
		}
		// Running over the modifications
		for (int modCounter=0 ; modCounter<variableModifications.length ; modCounter++) {
			int[] toModify = variableModifications[modCounter].residuesToBeModified(pepSeqOrig);
			for (int toModifyCounter=0; toModifyCounter<toModify.length ; toModifyCounter++) {
				// Make a copy of pepSeq
				char[] pepSeq = new char[pepSeqOrig.length];
				for (int c=0; c<pepSeqOrig.length ; c++) {
					pepSeq[c] = pepSeqOrig[c];
				}
				pepSeq[toModify[toModifyCounter]] = variableModifications[modCounter].oneLetterCodeOfModification();
				// Adding new peptide to array if it is not already there.
				boolean foundDuplicate = false;
				for (int c1 = toCheckRedundancyFrom ; c1<size() ; c1++) {
					Peptide pep1 = elementAt(c1);
					if (pep1.protein == pep.protein){
						if (pep1.seq.equals(new String(pepSeq))){
							foundDuplicate = true;
						}
					}
				}
				if (!foundDuplicate){
					add(new Peptide(new String(pepSeq) , pep.protein, pep.startIndexInProt, pep.endIndexInProt));
				}
				recursiveModificationAdder(pep, pepSeq, toCheckRedundancyFrom, numberOfModifications+1);
			}
		}		
	}
	
	
	
	private void createInitialPeptideList() {
		System.out.println("Log: Protease is: " + protease.proteaseName() + ". Number of allowed miscleavages: " + parametersUserDefined.numberMiscleavages);
		for (Protein protein : seqDB) {
			// Putting fixed modifications
			char[] tmpCharArr = protein.seq.toCharArray();
			for (int modCounter=0 ; modCounter<fixedModifications.length ; modCounter++) {
				int[] toModify = fixedModifications[modCounter].residuesToBeModified(tmpCharArr);
				for (int c=0; c<toModify.length ; c++) {
					tmpCharArr[toModify[c]] = fixedModifications[modCounter].oneLetterCodeOfModification();
				}
			}
			String sequence = new String(tmpCharArr);
			int[] cutSitesWithoutTermini = protease.cut(sequence);
			int[] cutSites = new int[cutSitesWithoutTermini.length+2];
			cutSites[0] = -1; // marking the N-terminal
			cutSites[cutSites.length-1] = sequence.length()-1; // marking the C-terminal 
			for (int c=0 ; c<cutSitesWithoutTermini.length ; c++) {
				cutSites[c+1] = cutSitesWithoutTermini[c];
			}
			for (int c1=0 ; c1<cutSites.length-1 ; c1++){
				for (int c2=1 ; c2<=parametersUserDefined.numberMiscleavages+1 ; c2++) {
					int endIndexOfPeptide = Math.min(c1+c2, cutSites.length-1);
					int pepLength = cutSites[endIndexOfPeptide]-cutSites[c1];
					if ((pepLength>=parametersUserDefined.minimalPeptideLength) && (pepLength<=parametersUserDefined.maximalPeptideLength)) {
						add(new Peptide(sequence.substring(cutSites[c1]+1, cutSites[endIndexOfPeptide]+1), protein, cutSites[c1]+1, cutSites[endIndexOfPeptide]));
					}
					if (c1+c2 >= cutSites.length-1) {
						break;
					}
				}
			}
		}
		System.out.println("Log: " + this.size() + " peptides created without modifications.");
	}
	
	public void print() {
		for (Peptide pep : this) {
			pep.print();
		}
	}

}

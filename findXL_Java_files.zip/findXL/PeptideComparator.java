package findXL;

import java.util.Comparator;

public class PeptideComparator implements Comparator<Peptide> {
	
	public int compare(Peptide arg0, Peptide arg1) {
		if (arg0.totalMass<arg1.totalMass) 
			return -1;
		else if (arg0.totalMass>arg1.totalMass) 
			return 1;
		else
			return 0;
	}
}

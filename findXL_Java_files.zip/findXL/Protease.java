package findXL;

public interface Protease {
	// Should return a short name of the protease, e.g. "Trypsin"
	public String proteaseName();
	
	// Should return the cut sites on the protein sequence. The cut is C-terminal to residue whose index is given. 
	public int[] cut(String seq);

}

package findXL;

public class Protein {

	protected final String proteinName;
	protected final String proteinAccession;
	protected final String proteinDescription;
	protected final String seq;
	protected final int id;
	protected final boolean decoy;
	
	public Protein(String seq, String proteinName, String proteinAccession, String proteinDescription, int id, boolean decoy) {
		this.seq = seq;
		this.proteinName = proteinName;
		this.proteinAccession = proteinAccession;
		this.proteinDescription = proteinDescription;
		this.id = id;
		this.decoy = decoy;
	}
	
	public String toString() {
		return id + ". Protein Name: " + proteinName + "   Protein accession code: " + proteinAccession + "   Protein description: " + proteinDescription + "\n" + seq + "\n"; 
	}

}

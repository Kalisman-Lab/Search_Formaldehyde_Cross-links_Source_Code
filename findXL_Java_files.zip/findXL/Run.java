package findXL;

import java.io.IOException;
import java.io.PrintWriter;

public class Run {

	public static void main(String[] args) {
		ParametersFixed parametersFixed = new ParametersFixed();
		ParametersUserDefined parametersUserDefined = new ParametersUserDefined();
		parametersUserDefined.fastaSequenceDatabaseFileName = args[0];
		parametersUserDefined.MSdataFileName = args[1];
		Modification[] variableModifications = {
				new ModificationMethionineOxydized(),
				new ModificationNtermAcetylated()            };
		Modification[] fixedModifications = {
				new ModificationCysteineWithIodoacetamide()  };
		Protease protease = new Trypsin();


		FastaProteinDatabase seqDB = new FastaProteinDatabase(parametersUserDefined.fastaSequenceDatabaseFileName , parametersUserDefined);
		PeptideArray peptides = new PeptideArray(seqDB,
				protease,
				fixedModifications, 
				variableModifications, 
				parametersFixed, 
				parametersUserDefined);
		MSdata msData = new MSdata(parametersUserDefined.MSdataFileName,
				parametersUserDefined.offsetMS1,
				parametersUserDefined.offsetMS2,
				parametersUserDefined.toleranceMS2);
		CoreSearch core = new CoreSearch(msData, peptides, parametersFixed, parametersUserDefined);
		core.preProcessing();
		core.findCandidates();
	}

}

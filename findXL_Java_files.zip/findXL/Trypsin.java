package findXL;

import java.util.Vector;

public class Trypsin implements Protease {

	public Trypsin() {	}

	public String proteaseName() {
		return "Trypsin";
	}

	public int[] cut(String seq) {
		Vector<Integer> outVec = new Vector<Integer>();
		
		// Specificity of trypsin
		for (int c=0; c<(seq.length()-1) ; c++) {
			if (seq.substring(c, c+1).equals("K") || seq.substring(c, c+1).equals("R")) {
				if (!seq.substring(c+1, c+2).equals("P")) {
					outVec.add(new Integer(c));
				}
			}
		}

		// Formatting the Vector into an int array
		int[] outArr = new int[outVec.size()];
		for (int c=0; c<outVec.size() ; c++) {
			outArr[c] = outVec.elementAt(c).intValue();
		}
		return outArr;
	}

}
